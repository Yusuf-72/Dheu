# Tarihsel veri planı

Bu prototipteki lider listesi yalnızca arayüz testi içindir; kapsamlı veya doğrulanmış tarihsel veri değildir.

Tam veri modeli için her kayıt şu alanları taşımalıdır:
- tarih aralığı ve takvim sistemi
- siyasi varlık / devlet kimliği
- hükümdar kimliği, saltanat başlangıcı ve bitişi
- başkent, eyaletler, şehirler ve sınırlar
- hanedan ve veraset ilişkileri
- kaynak ve güven düzeyi

Tarihsel veriler açık lisanslı kaynaklardan derlenmeli; her kaydın kaynağı ve lisansı saklanmalıdır.
