# IMPERIUM – Living History (Prototype 0.1)

Açık kaynaklı Godot 4 başlangıç prototipi. Windows ve Android için tasarlanmıştır.

## Çalıştırma
1. Godot 4.3 veya üzerini kurun.
2. Godot Project Manager > Import seçeneğiyle bu klasördeki `project.godot` dosyasını açın.
3. F6 değil, F5 ile ana sahneyi çalıştırın.

## Bu prototipte bulunanlar
- Basit 3D yerleşim sahnesi
- Dünya haritası kamerası
- Temsilî hükümdar kamerası
- Başlangıç yılı alanı
- Örnek medeniyet ve lider seçimi
- M/R görünüm kısayolları ve WASD kamera hareketi

## Henüz bulunmayanlar
Gerçek tarihsel dünya haritası, sarayda yürüyüş, NPC/elçi diyaloğu, diplomasi simülasyonu, savaş ve kuşatma, hanedan/veraset sistemi, kayıt-yükleme ve kapsamlı çevrimdışı tarih veri tabanı henüz uygulanmadı.

## Platform notu
Godot 4'ün Compatibility renderer'ı başlangıçta PC ve Android uyumluluğu için seçildi. Gerçekçi grafik hedefi için cihaz performansına göre daha sonra görsel kalite profilleri ve uygun renderer ayarları hazırlanmalıdır.
