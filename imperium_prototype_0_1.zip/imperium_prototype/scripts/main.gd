extends Node3D

# IMPERIUM prototype: a small playable foundation, not the complete game.
var map_camera: Camera3D
var ruler_camera: Camera3D
var status_label: Label
var mode_label: Label
var date_picker: SpinBox
var civ_picker: OptionButton
var leader_picker: OptionButton
var map_mode := true

const LEADERS := {
    "Ottoman Empire": ["Bayezid I", "Mehmed II", "Suleiman I"],
    "Byzantine Empire": ["Alexios I Komnenos", "Constantine XI"],
    "Mongol Empire": ["Genghis Khan", "Kublai Khan"],
    "France": ["Charlemagne", "Napoleon Bonaparte"],
    "England": ["William the Conqueror", "Henry V"]
}

func _ready() -> void:
    _build_world()
    _build_ui()
    _update_leaders()

func _build_world() -> void:
    var env := WorldEnvironment.new()
    var environment := Environment.new()
    environment.background_mode = Environment.BG_SKY
    environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    environment.ambient_light_color = Color(0.55, 0.62, 0.7)
    environment.ambient_light_energy = 0.7
    env.environment = environment
    add_child(env)

    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-48, -32, 0)
    sun.light_energy = 1.3
    add_child(sun)

    var ground := MeshInstance3D.new()
    var plane := PlaneMesh.new()
    plane.size = Vector2(100, 100)
    ground.mesh = plane
    var ground_mat := StandardMaterial3D.new()
    ground_mat.albedo_color = Color(0.25, 0.34, 0.24)
    ground.material_override = ground_mat
    add_child(ground)

    # Placeholder settlement made from primitive meshes.
    for i in range(9):
        var building := MeshInstance3D.new()
        var box := BoxMesh.new()
        box.size = Vector3(2.2, randf_range(2.5, 6.0), 2.2)
        building.mesh = box
        building.position = Vector3(randf_range(-16, 16), box.size.y / 2.0, randf_range(-16, 16))
        var mat := StandardMaterial3D.new()
        mat.albedo_color = [Color("#b9a17b"), Color("#8d7860"), Color("#c7bda4")][i % 3]
        building.material_override = mat
        add_child(building)

    map_camera = Camera3D.new()
    map_camera.position = Vector3(0, 34, 38)
    map_camera.rotation_degrees = Vector3(-42, 0, 0)
    map_camera.current = true
    add_child(map_camera)

    ruler_camera = Camera3D.new()
    ruler_camera.position = Vector3(0, 2, 8)
    ruler_camera.rotation_degrees = Vector3(-5, 180, 0)
    ruler_camera.current = false
    add_child(ruler_camera)

func _build_ui() -> void:
    var layer := CanvasLayer.new()
    add_child(layer)
    var panel := PanelContainer.new()
    panel.position = Vector2(16, 16)
    panel.custom_minimum_size = Vector2(300, 0)
    layer.add_child(panel)
    var layout := VBoxContainer.new()
    layout.add_theme_constant_override("separation", 8)
    panel.add_child(layout)

    var title := Label.new()
    title.text = "IMPERIUM | LIVING HISTORY"
    title.add_theme_font_size_override("font_size", 19)
    layout.add_child(title)

    var date_row := HBoxContainer.new()
    layout.add_child(date_row)
    date_row.add_child(_label("Başlangıç yılı"))
    date_picker = SpinBox.new()
    date_picker.min_value = -3000
    date_picker.max_value = 2100
    date_picker.value = 1389
    date_picker.step = 1
    date_row.add_child(date_picker)

    civ_picker = OptionButton.new()
    for civ in LEADERS.keys(): civ_picker.add_item(civ)
    civ_picker.item_selected.connect(_update_leaders)
    layout.add_child(civ_picker)

    leader_picker = OptionButton.new()
    layout.add_child(leader_picker)

    var map_button := Button.new()
    map_button.text = "Harita görünümü (M)"
    map_button.pressed.connect(_show_map)
    layout.add_child(map_button)

    var ruler_button := Button.new()
    ruler_button.text = "Hükümdar görünümü (R)"
    ruler_button.pressed.connect(_show_ruler)
    layout.add_child(ruler_button)

    mode_label = Label.new()
    mode_label.text = "Mod: Dünya haritası"
    layout.add_child(mode_label)
    status_label = Label.new()
    status_label.text = "Prototip hazır. Tarih ve lider seçimi temel düzeydedir."
    status_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    layout.add_child(status_label)

    var help := Label.new()
    help.text = "Harita: WASD ile kamera hareketi | M: Harita | R: Hükümdar"
    help.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    layout.add_child(help)

func _label(value: String) -> Label:
    var label := Label.new()
    label.text = value
    return label

func _update_leaders(_index: int = 0) -> void:
    if leader_picker == null: return
    leader_picker.clear()
    var civ := civ_picker.get_item_text(civ_picker.selected)
    for leader in LEADERS[civ]: leader_picker.add_item(leader)
    if status_label:
        status_label.text = civ + " seçildi. Lider seçip prototipi keşfet."

func _show_map() -> void:
    map_mode = true
    map_camera.current = true
    mode_label.text = "Mod: Dünya haritası"

func _show_ruler() -> void:
    map_mode = false
    ruler_camera.current = true
    mode_label.text = "Mod: Hükümdar görünümü (geçici sahne)"
    status_label.text = "Bu prototipte hükümdar kamerası temsilîdir; saray ve karakter etkileşimleri sonraki aşamada eklenecek."

func _unhandled_input(event: InputEvent) -> void:
    if event is InputEventKey and event.pressed and not event.echo:
        if event.keycode == KEY_M: _show_map()
        elif event.keycode == KEY_R: _show_ruler()

    if map_mode and event is InputEventKey and event.pressed:
        var move := Vector3.ZERO
        if event.keycode == KEY_W: move.z -= 2
        elif event.keycode == KEY_S: move.z += 2
        elif event.keycode == KEY_A: move.x -= 2
        elif event.keycode == KEY_D: move.x += 2
        map_camera.position += move
