extends Node3D

# IMPERIUM 0.3: playable vertical-slice prototype.
# Palace architecture and map geography are procedural placeholders, not surveyed historical assets.

const MAP_SPEED := 25.0
const PLAYER_SPEED := 5.0
const LEADERS := {
    "Osmanlı": ["I. Bayezid", "II. Mehmed", "I. Süleyman"],
    "Bizans": ["I. Aleksios Komnenos", "XI. Konstantinos"],
    "Moğol İmparatorluğu": ["Cengiz Han", "Kubilay Han"],
    "Fransa": ["Şarlman", "Napolyon Bonapart"],
    "İngiltere": ["Fatih William", "V. Henry"],
    "Mali": ["Sundiata Keita", "Mansa Musa"],
    "Ming Çin'i": ["Hongwu", "Yongle"],
    "Babür": ["Babür Şah", "Ekber Şah"]
}

var map_camera: Camera3D
var palace_camera: Camera3D
var player: CharacterBody3D
var player_camera: Camera3D
var npc_root: Node3D
var army_root: Node3D
var dialogue_panel: PanelContainer
var dialogue_text: Label
var selected_army: Node3D
var battle_active := false
var battle_status := "Ordu beklemede"
var map_mode := true
var move_vector := Vector2.ZERO
var look_drag := false
var last_pointer := Vector2.ZERO
var yaw := 0.0
var pitch := 0.0

var status_label: Label
var mode_label: Label
var date_picker: SpinBox
var civ_picker: OptionButton
var leader_picker: OptionButton

func _ready() -> void:
    _make_environment()
    _build_map()
    _build_palace()
    _build_npcs()
    _build_armies()
    _build_ui()
    _refresh_leaders()
    _show_map()

func _process(delta: float) -> void:
    if map_mode:
        var direction := Vector3(move_vector.x, 0, move_vector.y)
        if direction.length() > 0.01:
            map_camera.position += direction.normalized() * MAP_SPEED * delta
    else:
        _move_player(delta)
    _update_army_simulation(delta)

func _make_environment() -> void:
    var world := WorldEnvironment.new()
    var env := Environment.new()
    env.background_mode = Environment.BG_COLOR
    env.background_color = Color("#aebdca")
    env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    env.ambient_light_color = Color("#d5d0c1")
    env.ambient_light_energy = 0.75
    world.environment = env
    add_child(world)

    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-48, -32, 0)
    sun.light_energy = 1.15
    sun.shadow_enabled = true
    add_child(sun)

func _mat(color: Color, roughness := 0.9) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_color = color
    m.roughness = roughness
    return m

func _box(parent: Node3D, size: Vector3, pos: Vector3, color: Color) -> MeshInstance3D:
    var mesh_node := MeshInstance3D.new()
    var mesh := BoxMesh.new()
    mesh.size = size
    mesh_node.mesh = mesh
    mesh_node.position = pos
    mesh_node.material_override = _mat(color)
    parent.add_child(mesh_node)
    return mesh_node

func _cylinder(parent: Node3D, radius: float, height: float, pos: Vector3, color: Color) -> MeshInstance3D:
    var node := MeshInstance3D.new()
    var mesh := CylinderMesh.new()
    mesh.top_radius = radius
    mesh.bottom_radius = radius
    mesh.height = height
    node.mesh = mesh
    node.position = pos
    node.material_override = _mat(color)
    parent.add_child(node)
    return node

func _label3d(parent: Node3D, text_value: String, pos: Vector3, color := Color.WHITE) -> void:
    var label := Label3D.new()
    label.text = text_value
    label.position = pos
    label.font_size = 48
    label.pixel_size = 0.008
    label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
    label.modulate = color
    parent.add_child(label)

func _build_map() -> void:
    var map_root := Node3D.new()
    map_root.name = "StrategicMap"
    add_child(map_root)

    _box(map_root, Vector3(150, 0.5, 120), Vector3(0, -0.4, 0), Color("#9caa83"))

    # Abstract provinces and terrain zones for the first playable map slice.
    var provinces := [
        ["Rumeli", Vector3(-27, 0, -12), Vector2(25, 23), Color("#8eaa78")],
        ["Anadolu", Vector3(4, 0, 4), Vector2(34, 29), Color("#b6a27a")],
        ["Bursa", Vector3(-15, 0, 18), Vector2(17, 15), Color("#a4b88a")],
        ["Ege", Vector3(-31, 0, 35), Vector2(18, 17), Color("#b9ad83")],
        ["Karadeniz", Vector3(19, 0, -24), Vector2(29, 14), Color("#91a982")],
        ["Suriye", Vector3(35, 0, 32), Vector2(22, 18), Color("#c1a77c")]
    ]
    for p in provinces:
        var region := _box(map_root, Vector3(p[2].x, 0.08, p[2].y), p[1] + Vector3(0, 0.0, 0), p[3])
        region.name = str(p[0])
        _label3d(map_root, str(p[0]), p[1] + Vector3(0, 0.25, 0), Color("#26332a"))

    # Stylized water and river.
    _box(map_root, Vector3(150, 0.15, 13), Vector3(0, -0.05, -48), Color("#668fa8"))
    _box(map_root, Vector3(150, 0.15, 11), Vector3(0, -0.05, 52), Color("#668fa8"))
    var river := _box(map_root, Vector3(3.5, 0.12, 78), Vector3(-5, 0.02, 0), Color("#668fa8"))
    river.rotation_degrees.y = 12

    _add_city(map_root, "Edirne", Vector3(-25, 0.5, -12))
    _add_city(map_root, "İstanbul", Vector3(-12, 0.5, 0))
    _add_city(map_root, "Bursa", Vector3(-16, 0.5, 17))
    _add_city(map_root, "Ankara", Vector3(12, 0.5, 8))
    _add_city(map_root, "Konya", Vector3(17, 0.5, 28))
    _add_city(map_root, "Sivas", Vector3(31, 0.5, -3))

    map_camera = Camera3D.new()
    map_camera.position = Vector3(0, 62, 55)
    map_camera.rotation_degrees = Vector3(-52, 0, 0)
    map_camera.current = true
    map_camera.fov = 55
    map_root.add_child(map_camera)

func _add_city(parent: Node3D, city_name: String, pos: Vector3) -> void:
    _cylinder(parent, 0.9, 1.2, pos, Color("#5b4632"))
    _label3d(parent, city_name, pos + Vector3(0, 2.0, 0), Color("#202a25"))

func _build_palace() -> void:
    var palace := Node3D.new()
    palace.name = "PalaceInterior"
    add_child(palace)

    _box(palace, Vector3(34, 0.6, 27), Vector3(0, -0.35, 0), Color("#8a765f"))
    _box(palace, Vector3(34, 0.5, 1), Vector3(0, 6.5, -13), Color("#9b3c2d"))
    _box(palace, Vector3(34, 0.5, 1), Vector3(0, 6.5, 13), Color("#9b3c2d"))
    _box(palace, Vector3(1, 0.5, 27), Vector3(-16.5, 6.5, 0), Color("#9b3c2d"))
    _box(palace, Vector3(1, 0.5, 27), Vector3(16.5, 6.5, 0), Color("#9b3c2d"))

    # Walls with an open front so the player can enter and explore.
    _box(palace, Vector3(34, 7, 0.8), Vector3(0, 3.2, -13), Color("#d1c1a3"))
    _box(palace, Vector3(0.8, 7, 27), Vector3(-16.5, 3.2, 0), Color("#d1c1a3"))
    _box(palace, Vector3(0.8, 7, 27), Vector3(16.5, 3.2, 0), Color("#d1c1a3"))
    _box(palace, Vector3(10, 7, 0.8), Vector3(-12, 3.2, 13), Color("#d1c1a3"))
    _box(palace, Vector3(10, 7, 0.8), Vector3(12, 3.2, 13), Color("#d1c1a3"))

    for x in [-13.0, -7.0, 7.0, 13.0]:
        _cylinder(palace, 0.48, 6.3, Vector3(x, 3.0, -8), Color("#e3d4b8"))
        _cylinder(palace, 0.48, 6.3, Vector3(x, 3.0, 8), Color("#e3d4b8"))
        _cylinder(palace, 0.58, 0.35, Vector3(x, 6.15, -8), Color("#b28a4e"))
        _cylinder(palace, 0.58, 0.35, Vector3(x, 6.15, 8), Color("#b28a4e"))

    # Throne dais and throne.
    _box(palace, Vector3(9, 0.8, 5), Vector3(0, 0.35, -8.5), Color("#b28a4e"))
    _box(palace, Vector3(4.5, 0.6, 2.2), Vector3(0, 1.1, -9), Color("#7e2725"))
    _box(palace, Vector3(4.5, 3.0, 0.65), Vector3(0, 2.5, -10), Color("#7e2725"))
    _box(palace, Vector3(0.8, 3.4, 2.2), Vector3(-2.3, 2.4, -9), Color("#b28a4e"))
    _box(palace, Vector3(0.8, 3.4, 2.2), Vector3(2.3, 2.4, -9), Color("#b28a4e"))
    _label3d(palace, "TAHT ODASI", Vector3(0, 5.2, -5), Color("#e9d8b0"))

    # A simple placeholder ruler silhouette.
    _cylinder(palace, 0.42, 1.7, Vector3(0, 2.0, -5.6), Color("#7e2725"))
    _cylinder(palace, 0.38, 0.7, Vector3(0, 3.15, -5.6), Color("#c99b72"))
    var crown := _cylinder(palace, 0.48, 0.18, Vector3(0, 3.58, -5.6), Color("#c6a04b"))

    player = CharacterBody3D.new()
    player.name = "Player"
    player.position = Vector3(0, 0.2, 7)
    palace.add_child(player)

    var collision := CollisionShape3D.new()
    var capsule := CapsuleShape3D.new()
    capsule.radius = 0.38
    capsule.height = 1.8
    collision.shape = capsule
    collision.position.y = 0.9
    player.add_child(collision)

    player_camera = Camera3D.new()
    player_camera.position = Vector3(0, 1.55, 0)
    player_camera.current = false
    player_camera.fov = 75
    player.add_child(player_camera)
    palace_camera = player_camera

func _build_ui() -> void:
    var layer := CanvasLayer.new()
    add_child(layer)

    var panel := PanelContainer.new()
    panel.position = Vector2(12, 12)
    panel.custom_minimum_size = Vector2(255, 0)
    layer.add_child(panel)
    var v := VBoxContainer.new()
    v.add_theme_constant_override("separation", 5)
    panel.add_child(v)

    var title := Label.new()
    title.text = "IMPERIUM | LIVING HISTORY"
    title.add_theme_font_size_override("font_size", 16)
    v.add_child(title)

    var row := HBoxContainer.new()
    v.add_child(row)
    row.add_child(_label("Yıl"))
    date_picker = SpinBox.new()
    date_picker.min_value = -3000
    date_picker.max_value = 2100
    date_picker.value = 1389
    date_picker.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    row.add_child(date_picker)

    civ_picker = OptionButton.new()
    civ_picker.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    for c in LEADERS.keys():
        civ_picker.add_item(c)
    civ_picker.item_selected.connect(_refresh_leaders)
    v.add_child(civ_picker)

    leader_picker = OptionButton.new()
    leader_picker.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    v.add_child(leader_picker)

    var map_btn := Button.new()
    map_btn.text = "Haritaya geç"
    map_btn.custom_minimum_size.y = 42
    map_btn.pressed.connect(_show_map)
    v.add_child(map_btn)

    var palace_btn := Button.new()
    palace_btn.text = "Sarayda dolaş"
    palace_btn.custom_minimum_size.y = 42
    palace_btn.pressed.connect(_show_palace)
    v.add_child(palace_btn)

    mode_label = _label("Mod: Stratejik harita")
    v.add_child(mode_label)
    status_label = _label("1389 Osmanlı prototipi")
    status_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    v.add_child(status_label)

    # Bottom-left touch movement controls.
    var controls := VBoxContainer.new()
    controls.set_anchors_preset(Control.PRESET_BOTTOM_LEFT)
    controls.position = Vector2(18, -150)
    controls.add_theme_constant_override("separation", 3)
    layer.add_child(controls)
    var up := _move_button("▲", Vector2(58, 46), Vector2(0, -1))
    controls.add_child(up)
    var row2 := HBoxContainer.new()
    controls.add_child(row2)
    row2.add_child(_move_button("◀", Vector2(58, 46), Vector2(-1, 0)))
    row2.add_child(_move_button("▼", Vector2(58, 46), Vector2(0, 1)))
    row2.add_child(_move_button("▶", Vector2(58, 46), Vector2(1, 0)))

    var zooms := HBoxContainer.new()
    zooms.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
    zooms.position = Vector2(-122, -65)
    layer.add_child(zooms)
    var plus := Button.new()
    plus.text = "+"
    plus.custom_minimum_size = Vector2(55, 48)
    plus.pressed.connect(_zoom.bind(-6.0))
    zooms.add_child(plus)
    var minus := Button.new()
    minus.text = "−"
    minus.custom_minimum_size = Vector2(55, 48)
    minus.pressed.connect(_zoom.bind(6.0))
    zooms.add_child(minus)

    var interact := Button.new()
    interact.text = "Etkileşim"
    interact.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
    interact.position = Vector2(-130, -125)
    interact.custom_minimum_size = Vector2(115, 48)
    interact.pressed.connect(_interact)
    layer.add_child(interact)

    var army_button := Button.new()
    army_button.text = "Ordu seç / hareket"
    army_button.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
    army_button.position = Vector2(-160, -185)
    army_button.custom_minimum_size = Vector2(145, 48)
    army_button.pressed.connect(_army_order)
    layer.add_child(army_button)

    var battle_button := Button.new()
    battle_button.text = "Çatışma başlat"
    battle_button.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
    battle_button.position = Vector2(-160, -240)
    battle_button.custom_minimum_size = Vector2(145, 48)
    battle_button.pressed.connect(_toggle_battle)
    layer.add_child(battle_button)

    dialogue_panel = PanelContainer.new()
    dialogue_panel.set_anchors_preset(Control.PRESET_CENTER_BOTTOM)
    dialogue_panel.position = Vector2(-240, -150)
    dialogue_panel.custom_minimum_size = Vector2(480, 105)
    dialogue_panel.visible = false
    layer.add_child(dialogue_panel)
    dialogue_text = Label.new()
    dialogue_text.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    dialogue_panel.add_child(dialogue_text)

func _label(value: String) -> Label:
    var l := Label.new()
    l.text = value
    return l

func _move_button(text_value: String, size: Vector2, dir: Vector2) -> Button:
    var b := Button.new()
    b.text = text_value
    b.custom_minimum_size = size
    b.button_down.connect(_set_move.bind(dir))
    b.button_up.connect(_clear_move)
    return b

func _set_move(dir: Vector2) -> void:
    move_vector = dir

func _clear_move() -> void:
    move_vector = Vector2.ZERO

func _refresh_leaders(_index := 0) -> void:
    if leader_picker == null:
        return
    leader_picker.clear()
    var civ := civ_picker.get_item_text(civ_picker.selected)
    for leader in LEADERS[civ]:
        leader_picker.add_item(leader)
    if status_label:
        status_label.text = civ + " seçildi. Liderini belirle."

func _show_map() -> void:
    map_mode = true
    move_vector = Vector2.ZERO
    map_camera.current = true
    mode_label.text = "Mod: Stratejik harita"

func _show_palace() -> void:
    map_mode = false
    move_vector = Vector2.ZERO
    player_camera.current = true
    mode_label.text = "Mod: Sarayda birinci şahıs"
    status_label.text = "Ekrana dokunup sürükleyerek bakışını çevir; yön tuşlarıyla yürü."

func _zoom(amount: float) -> void:
    map_camera.position.y = clampf(map_camera.position.y + amount, 18.0, 100.0)
    map_camera.position.z = clampf(map_camera.position.z + amount, 18.0, 110.0)

func _move_player(delta: float) -> void:
    var forward := -player.global_transform.basis.z
    var right := player.global_transform.basis.x
    var dir := (right * move_vector.x + forward * -move_vector.y)
    dir.y = 0
    if dir.length() > 0.01:
        dir = dir.normalized()
    player.velocity.x = dir.x * PLAYER_SPEED
    player.velocity.z = dir.z * PLAYER_SPEED
    player.velocity.y -= 20.0 * delta
    player.move_and_slide()

func _interact() -> void:
    if map_mode:
        if selected_army:
            _show_dialogue("Ordu seçildi: " + str(selected_army.get_meta("army_name", "Ordu")) + ". 'Ordu seç / hareket' düğmesiyle hedef konuma ilerlet.")
        else:
            _show_dialogue("Harita üzerinde birlikleri seçip emir verebilirsin. Bu prototipte örnek Osmanlı birlikleri bulunuyor.")
        return
    var nearest: Node3D = null
    var nearest_distance := 4.5
    for npc in npc_root.get_children():
        if npc is Node3D:
            var d := player.global_position.distance_to(npc.global_position)
            if d < nearest_distance:
                nearest = npc
                nearest_distance = d
    if nearest:
        _show_dialogue(str(nearest.get_meta("dialogue", "Size nasıl yardımcı olabilirim?")))
    else:
        _show_dialogue("Yakında konuşabileceğin bir görevli yok. Vezir veya elçiye yaklaş.")

func _show_dialogue(message: String) -> void:
    dialogue_text.text = message
    dialogue_panel.visible = true

func _build_npcs() -> void:
    npc_root = Node3D.new()
    npc_root.name = "PalaceNPCs"
    add_child(npc_root)
    _make_npc("Sadrazam", Vector3(-5, 0, 1), Color("#4b2630"),
        "Hünkârım, Rumeli'deki birliklerin iaşesi azalmaktadır. Yeni erzak gönderilmesini öneririm.")
    _make_npc("Bizans Elçisi", Vector3(5, 0, 1), Color("#344a73"),
        "Cihan hükümdarı, imparatorumuz barış ve ticaret şartlarını görüşmek üzere elçisini gönderdi.")
    _make_npc("Saray Muhafızı", Vector3(-8, 0, 5), Color("#344b3b"),
        "Emriniz başım üstüne hünkârım. Taht odasının güvenliği sağlandı.")
    _make_npc("Divan Kâtibi", Vector3(8, 0, 5), Color("#66513a"),
        "Divan kayıtları hazır. Vergi, asker ve eyalet raporlarını önünüze getirebilirim.")

func _make_npc(npc_name: String, pos: Vector3, tunic_color: Color, line: String) -> void:
    var npc := Node3D.new()
    npc.name = npc_name
    npc.position = pos
    npc.set_meta("dialogue", npc_name + ": " + line)
    npc_root.add_child(npc)
    _cylinder(npc, 0.34, 1.35, Vector3(0, 1.0, 0), tunic_color)
    _cylinder(npc, 0.25, 0.42, Vector3(0, 1.92, 0), Color("#bd8c69"))
    _cylinder(npc, 0.29, 0.16, Vector3(0, 2.2, 0), Color("#3c3028"))
    _label3d(npc, npc_name, Vector3(0, 2.65, 0), Color("#fff0cf"))

func _build_armies() -> void:
    army_root = Node3D.new()
    army_root.name = "Armies"
    add_child(army_root)
    _make_army("Bursa Birliği", Vector3(-16, 0.7, 17), Color("#8c3028"))
    _make_army("Edirne Birliği", Vector3(-25, 0.7, -12), Color("#8c3028"))
    _make_army("Anadolu Birliği", Vector3(12, 0.7, 8), Color("#8c3028"))
    _make_army("Sınır Birliği", Vector3(31, 0.7, -3), Color("#8c3028"))

func _make_army(army_name: String, pos: Vector3, army_color: Color) -> void:
    var army := Node3D.new()
    army.name = army_name
    army.position = pos
    army.set_meta("army_name", army_name)
    army.set_meta("target", pos)
    army.set_meta("strength", 100)
    army_root.add_child(army)
    _cylinder(army, 0.85, 1.0, Vector3.ZERO, army_color)
    _box(army, Vector3(0.12, 2.0, 0.12), Vector3(0, 1.35, 0), Color("#493323"))
    _box(army, Vector3(0.9, 0.6, 0.08), Vector3(0.48, 1.85, 0), Color("#d3b66d"))
    _label3d(army, army_name, Vector3(0, 2.5, 0), Color("#fff2d1"))

func _army_order() -> void:
    if not map_mode:
        _show_dialogue("Ordu emirleri için önce stratejik haritaya geç.")
        return
    if army_root.get_child_count() == 0:
        return
    if selected_army == null:
        selected_army = army_root.get_child(0)
        _show_dialogue(str(selected_army.get_meta("army_name")) + " seçildi. Sonraki dokunuşta hedef belirleme özelliği eklenecek; bu sürümde hedef merkez bölge.")
    else:
        var target := Vector3(0, 0.7, 0)
        selected_army.set_meta("target", target)
        _show_dialogue(str(selected_army.get_meta("army_name")) + " merkez bölgeye ilerleme emri aldı.")
        selected_army = null

func _update_army_simulation(delta: float) -> void:
    if not army_root:
        return
    for army in army_root.get_children():
        var target: Vector3 = army.get_meta("target")
        var offset := target - army.position
        if offset.length() > 0.4:
            army.position += offset.normalized() * 3.0 * delta

func _toggle_battle() -> void:
    battle_active = not battle_active
    if battle_active:
        battle_status = "Çatışma başladı: örnek birlik gücü ve kayıp simülasyonu etkin."
        _show_dialogue(battle_status)
    else:
        battle_status = "Çatışma durduruldu."
        _show_dialogue(battle_status)


func _unhandled_input(event: InputEvent) -> void:
    if event is InputEventKey and event.pressed and not event.echo:
        if event.keycode == KEY_M:
            _show_map()
        elif event.keycode == KEY_R:
            _show_palace()
    if not map_mode and event is InputEventScreenTouch:
        if event.pressed:
            look_drag = true
            last_pointer = event.position
        else:
            look_drag = false
    elif not map_mode and event is InputEventScreenDrag:
        var delta := event.position - last_pointer
        last_pointer = event.position
        _look(delta)
    elif not map_mode and event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
        look_drag = event.pressed
        last_pointer = event.position
    elif not map_mode and event is InputEventMouseMotion and look_drag:
        var delta := event.position - last_pointer
        last_pointer = event.position
        _look(delta)

func _look(delta: Vector2) -> void:
    yaw -= delta.x * 0.004
    pitch = clampf(pitch - delta.y * 0.004, -1.0, 1.0)
    player.rotation.y = yaw
    player_camera.rotation.x = pitch
