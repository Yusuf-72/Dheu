# IMPERIUM 0.4 – Android/PC prototype

## New in 0.4
- Palace NPCs: grand vizier, foreign envoy, guard and divan scribe
- Proximity-based interaction and dialogue panel
- Stylized Bayezid-era ruler/palace scene from the prior prototype
- Strategic map army markers
- Basic army selection and movement order toward a test destination
- Toggleable placeholder battle state
- Touch controls and map/palace camera switching

## Run
Open `project.godot` in Godot 4.3 or newer.

## Android export
Install Godot Android export templates and Android SDK/JDK, create an Android export preset, then export a debug APK.

## Scope and limitations
This is still an early prototype, not a finished commercial-quality game. NPCs are simple geometric stand-ins, dialogue is scripted, the map is a small stylized test region, and the battle toggle is not yet a tactical combat system. It does not yet contain a historically verified global map, researched leader models, full diplomatic negotiation, siege mechanics, dynasty succession, save/load, or the complete civilizations database.
